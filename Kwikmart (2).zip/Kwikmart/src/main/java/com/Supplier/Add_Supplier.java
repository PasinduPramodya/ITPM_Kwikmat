package com.Supplier;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Employee.Employee_DB_Utill;

 
@WebServlet("/Add_Supplier")
public class Add_Supplier extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
		String name = request.getParameter("name");
		String tell = request.getParameter("con");
		String companyName = request.getParameter("comNmae");
		String companyAddress = request.getParameter("comPanyADD");
	 
	
		
		boolean isstru;
		
		isstru=  Supplier_DB_Utill.Add_Supplier(name, tell, companyName, companyAddress);
			
		if(isstru == true) {
			 
			   
			 RequestDispatcher dis = request.getRequestDispatcher("home.jsp");
			 dis.forward(request, response);
			
		}
		else {
			RequestDispatcher dis1 = request.getRequestDispatcher("unsucsees.jsp");
			dis1.forward(request, response);
			
		}
		
		
		
		
		
		
	}

}
