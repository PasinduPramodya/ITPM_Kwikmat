package com.Supplier;

public class Supplier {
	
	
	private int  supplier_ID;
	private String  supplier_Name;
	private String  contact_Number;
	private String  company_Name;
	private String  company_Address;
	
	
	
	public Supplier(int supplier_ID, String supplier_Name, String contact_Number, String company_Name,String company_Address) {
		 
		this.supplier_ID = supplier_ID;
		this.supplier_Name = supplier_Name;
		this.contact_Number = contact_Number;
		this.company_Name = company_Name;
		this.company_Address = company_Address;
	}



	public int getSupplier_ID() {
		return supplier_ID;
	}


 



	public String getSupplier_Name() {
		return supplier_Name;
	}

 


	public String getContact_Number() {
		return contact_Number;
	}


 


	public String getCompany_Name() {
		return company_Name;
	}

 



	public String getCompany_Address() {
		return company_Address;
	}

 
	
	
	 
	

}
