package com.Supplier;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Employee.Employee;
 

 
@WebServlet("/Search_Supplier")
public class Search_Supplier extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 
		 
		String SupID = request.getParameter("supID");
	
		try {
		 List<Supplier> Supplier_Details =  Supplier_DB_Utill.validate(SupID);
		 request.setAttribute("Supplier_Details",Supplier_Details);
		}
		catch(Exception e) {
			  e.printStackTrace();
		  }
		
		 RequestDispatcher dis = request.getRequestDispatcher("Supplier_Account.jsp");
		 dis.forward(request, response);
		
		
		
		
		
		
	}

}
