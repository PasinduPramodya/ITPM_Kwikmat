package com.Supplier;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.Employee.Employee;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class Supplier_DB_Utill {

	
	


public static List<Supplier>validate(String supid){
	
		
		ArrayList<Supplier> emp = new ArrayList<>();
		
		String url="jdbc:mysql://localhost:3306/kwikmart";
    	String user="root";
    	String pass="Ashan123";														
																				
																				

		try {
																				
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="SELECT * FROM kwikmart.supplier WHERE Supplier_ID ='"+supid+"' ";
			
			ResultSet rs = stmt.executeQuery(sql);
			
			
			if (rs.next()){
			
			 
				
				
				int id=rs.getInt(1);
				String Name = rs.getString(2);
				String cont = rs.getString(3);
				String Company_Name = rs.getString(4); 
				String Company_Address= rs.getString(5);
				 
				 
			
				Supplier p = new Supplier(id,Name,cont,Company_Name,Company_Address);
				emp.add(p);
			}
			else {
				
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		return emp;
		
	}
	
	
	
    public static boolean Add_Supplier(String name,String pnumber, String companyName, String companyAddress ) {
		
    	boolean isSuccess = false;
    	
    	
    	String url="jdbc:mysql://localhost:3306/kwikmart";
    	String user="root";
    	String pass="Ashan123";
    	
    	
try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			
			String sql ="INSERT INTO kwikmart.supplier values(0,'"+name+"','"+pnumber+"','"+companyName+"','"+companyAddress+"')";
			
			int rs = stmt.executeUpdate(sql);
			
			
			if (rs>0) {
				
			isSuccess= true;	
				
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
    	
    	
    	
    	
    	
    	return isSuccess;
    	
    }
    
    


	public static boolean delete_Supplier(String ID) {
		
		int id = Integer.parseInt(ID);
		
		
     boolean isSuccess = false;
		
		

		
 	String url="jdbc:mysql://localhost:3306/kwikmart";
	String user="root";
	String pass="Ashan123";
		
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="DELETE FROM kwikmart.supplier where Supplier_ID ='"+id +"' ";	
			int rs = stmt.executeUpdate(sql);
			
			if (rs>0) {
				        
			isSuccess= true;	
				
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
		
		
		
	}
	
    
    
    
	  
    
	 public static boolean Update_Supplier(String id,String name,String price, String type, String NUMBER_OF_PRODUCT ) {
			
	    	boolean isSuccess = false;
	    	
	    	
	    	
	    	String url="jdbc:mysql://localhost:3306/kwikmart";
	    	String user="root";
	    	String pass="Ashan123";
	    	
	    	
	try {
				
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = (Connection) DriverManager.getConnection(url,user,pass);
				Statement stmt = (Statement) con.createStatement();
				String sql ="update kwikmart.supplier set Supplier_Name ='"+name+"' ,Contact_Number ='"+price +"' ,Company_Name ='"+type+"' ,Company_Address ='"+type +"'  where  Supplier_ID ='"+id +"'";
				int rs = stmt.executeUpdate(sql);
				
				 
				
				
				
				
				
				if (rs>0) {
					
				isSuccess= true;	
					
				}
				else {
					isSuccess = false;
				}
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
	    	
	    	
	    	
	    	
	    	
	    	return isSuccess;
	    	
	    }
	    
	    
	  
	
	
	
}
