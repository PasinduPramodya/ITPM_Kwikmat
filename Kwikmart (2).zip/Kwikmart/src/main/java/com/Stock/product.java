package com.Stock;

public class product {

	private int product_id;
	private String name;
	private String price;
	private String type;
	private String number;
	private String location;
	private String supplyer ;
	private String DISCRIPTION;
	
	
	public product(int product_id, String name, String price, String type, String number, String location,String supplyer, String DISCRIPTION) {
		 
		this.product_id = product_id;
		this.name = name;
		this.price = price;
		this.type = type;
		this.number = number;
		this.location = location;
		this.supplyer = supplyer;
		this.DISCRIPTION = DISCRIPTION;
	}


	public int getProduct_id() {
		return product_id;
	}


	 

	public String getName() {
		return name;
	}


	 


	public String getPrice() {
		return price;
	}


	 

	public String getType() {
		return type;
	}


	 


	public String getNumber() {
		return number;
	}


	 


	public String getLocation() {
		return location;
	}


	 


	public String getSupplyer() {
		return supplyer;
	}


	 


	public String getDISCRIPTION() {
		return DISCRIPTION;
	}


	 
	
	
	 



	 






 


	 
 
	
	
	
	
} 
