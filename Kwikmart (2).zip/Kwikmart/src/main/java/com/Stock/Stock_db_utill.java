package com.Stock;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
 
public class Stock_db_utill {
	
public static List<product>validate(String proID){
	
		
		ArrayList<product> stock = new ArrayList<>();
		
		String url="jdbc:mysql://localhost:3306/kwikmart";
    	String user="root";
    	String pass="Ashan123";														
																				
																				

		try {
																				
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="SELECT * FROM kwikmart.product WHERE Product_ID ='"+proID+"' ";
			
			ResultSet rs = stmt.executeQuery(sql);
			
			
			if (rs.next()){
			
			 
				
				
				int id=rs.getInt(1);
				String Name = rs.getString(2);
				String price = rs.getString(3);
				String type = rs.getString(4); 
				String NOFP= rs.getString(5);
				String location = rs.getString(6);
				String supplier = rs.getString(7);
				String description = rs.getString(8);
				 
			
				product p = new product(id,Name,price,type,NOFP,location,supplier,description);
				stock.add(p);
			}
			else {
				
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		return stock;
		
	}
	
	
    public static boolean add_Stock(String name,String price, String type, String NUMBER_OF_PRODUCT, String location, String supplier, String discription ) {
		
    	boolean isSuccess = false;
    	
    	
    	String url="jdbc:mysql://localhost:3306/kwikmart";
    	String user="root";
    	String pass="Ashan123";
    	
    	
try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="INSERT INTO kwikmart.product values(0,'"+name+"','"+price+"','"+type+"','"+NUMBER_OF_PRODUCT+"','"+location+"','"+supplier+"','"+discription+"' )";
			int rs = stmt.executeUpdate(sql);
			
			
			if (rs>0) {
				
			isSuccess= true;	
				
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
    	
    	
    	
    	
    	
    	return isSuccess;
    	
    }
    
    
    
    
  public static boolean Update_Stock(String id,String name,String price, String type, String NUMBER_OF_PRODUCT, String location, String supplier, String discription ) {
		
    	boolean isSuccess = false;
    	
    	
    	
    	String url="jdbc:mysql://localhost:3306/kwikmart";
    	String user="root";
    	String pass="Ashan123";
    	
    	
try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="update kwikmart.product set Product_name ='"+name+"' ,Product_Price ='"+price +"' ,Product_Type ='"+type +"' , number_of_product='"+NUMBER_OF_PRODUCT+"' , Product_location='"+location+"' , Product_supplierr_ID='"+supplier+"' , Product_description='"+discription+"' where  Product_ID ='"+id +"'  ";
			int rs = stmt.executeUpdate(sql);
			
			 
			
			
			
			
			
			if (rs>0) {
				
			isSuccess= true;	
				
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
    	
    	
    	
    	
    	
    	return isSuccess;
    	
    }
    
    
  

	public static boolean deleteStock(String ID) {
		
		int id = Integer.parseInt(ID);
		
		
     boolean isSuccess = false;
		
		

		
 	String url="jdbc:mysql://localhost:3306/kwikmart";
	String user="root";
	String pass="Ashan123";
		
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="DELETE FROM kwikmart.product where Product_ID ='"+id +"' ";	
			int rs = stmt.executeUpdate(sql);
			
			if (rs>0) {
				        
			isSuccess= true;	
				
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
		
		
		
	}
	
	
	
	
    
  
  
  
    
}
