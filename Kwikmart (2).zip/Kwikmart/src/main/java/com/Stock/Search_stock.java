package com.Stock;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 
@WebServlet("/Search_stock")
public class Search_stock extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		String productid = request.getParameter("pID");
	
		try {
		 List<product> stock_Details= Stock_db_utill.validate(productid);
		 request.setAttribute("stock_Details",stock_Details);
		}
		catch(Exception e) {
			  e.printStackTrace();
		  }
		
		 RequestDispatcher dis = request.getRequestDispatcher("Stock_account.jsp");
		 dis.forward(request, response);
		
	}
	

}
