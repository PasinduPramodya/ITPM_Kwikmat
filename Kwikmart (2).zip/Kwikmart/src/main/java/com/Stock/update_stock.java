package com.Stock;

import java.io.IOException;
 

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

 
@WebServlet("/update_stock")
public class update_stock extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String price = request.getParameter("Price");
		String type = request.getParameter("type");
		String NUMBER_OF_PRODUCT = request.getParameter("Number");
		String location = request.getParameter("Location");
		String supplier = request.getParameter("Supplyer");
		String discription = request.getParameter("DISCRIPTION");
	
		
		boolean isstru;
		
		isstru=Stock_db_utill.Update_Stock(id, name, price, type, NUMBER_OF_PRODUCT, location, supplier, discription);
			
		if(isstru == true) {
			 
			  
			  
			 
			 RequestDispatcher dis = request.getRequestDispatcher("home.jsp");
			 dis.forward(request, response);
			
		}
		else {
			RequestDispatcher dis1 = request.getRequestDispatcher("unsucsees.jsp");
			dis1.forward(request, response);
			
		}
		
	}

}
