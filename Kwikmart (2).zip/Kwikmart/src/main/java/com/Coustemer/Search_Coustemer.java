package com.Coustemer;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 
 
 

 
@WebServlet("/Search_Coustemer")
public class Search_Coustemer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		
		String productid = request.getParameter("cid");
		
		try {
		 List <coustemer> stock_Details= Coustemer_db_utill.validate(productid);
		 request.setAttribute("stock_Details",stock_Details);
		}
		catch(Exception e) {
			  e.printStackTrace();
		  }
		
		 RequestDispatcher dis = request.getRequestDispatcher("Coustemer_account.jsp");
		 dis.forward(request, response);
		
	}
	
	}


