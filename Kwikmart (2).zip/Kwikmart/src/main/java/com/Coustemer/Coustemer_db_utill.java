package com.Coustemer;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.Stock.product;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class Coustemer_db_utill {

	
	

public static List<coustemer>validate(String cusid){
	
		
		ArrayList<coustemer> cous = new ArrayList<>();
		
		String url="jdbc:mysql://localhost:3306/kwikmart";
    	String user="root";
    	String pass="Ashan123";														
																				
																				

		try {
																				
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="SELECT * FROM kwikmart.customer WHERE Customer_ID ='"+cusid+"' ";
			
			ResultSet rs = stmt.executeQuery(sql);
			
			
			if (rs.next()){
			
			 
				
				
				int id=rs.getInt(1);
				String Name = rs.getString(2);
				String price = rs.getString(3);
				String type = rs.getString(4); 
				String NOFP= rs.getString(5);
			
				coustemer p = new coustemer(id,Name,price,type,NOFP);
				cous.add(p);
			}
			else {
				
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		return cous;
		
	}
	
	
    public static boolean add_Coustemer(String first_name,String last_name, String conact, String email   ) {
		
    	boolean isSuccess = false;
    	
    	
    	String url="jdbc:mysql://localhost:3306/kwikmart";
    	String user="root";
    	String pass="Ashan123";
    	
    	
try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="INSERT INTO kwikmart.customer values(0,'"+first_name+"','"+last_name+"','"+conact+"','"+email+"')";
			int rs = stmt.executeUpdate(sql);
			
			
			if (rs>0) {
				
			isSuccess= true;	
				
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
    	
    	
    	
    	
    	
    	return isSuccess;
    	
    }
    
    
    
    
 public static boolean Update_Coustemer(String id,String name,String price, String type, String NUMBER_OF_PRODUCT ) {
		
    	boolean isSuccess = false;
    	
    	
    	
    	String url="jdbc:mysql://localhost:3306/kwikmart";
    	String user="root";
    	String pass="Ashan123";
    	
    	
try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="update kwikmart.customer set First_Nmae ='"+name+"' ,Last_Name ='"+price +"' ,Contact_number ='"+type +"' , email='"+NUMBER_OF_PRODUCT+"'   where  Customer_ID ='"+id +"'  ";
			int rs = stmt.executeUpdate(sql);
			
			 
			
			
			
			
			
			if (rs>0) {
				
			isSuccess= true;	
				
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
    	
    	
    	
    	
    	
    	return isSuccess;
    	
    }
    
    
  

	public static boolean delete_Coustemer(String ID) {
		
		int id = Integer.parseInt(ID);
		
		
     boolean isSuccess = false;
		
		

		
 	String url="jdbc:mysql://localhost:3306/kwikmart";
	String user="root";
	String pass="Ashan123";
		
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="DELETE FROM kwikmart.customer where Customer_ID ='"+id +"' ";	
			int rs = stmt.executeUpdate(sql);
			
			if (rs>0) {
				        
			isSuccess= true;	
				
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
		
		
		
	}
	
	
	
	
	
}
