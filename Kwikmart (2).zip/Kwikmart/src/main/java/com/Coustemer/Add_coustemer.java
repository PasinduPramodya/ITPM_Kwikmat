package com.Coustemer;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

 
@WebServlet("/Add_coustemer")
public class Add_coustemer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String first_name = request.getParameter("name");
		String last_name = request.getParameter("type");
		String conact = request.getParameter("Price");
		String email = request.getParameter("Supplyer");
		 
	
		
		boolean isstru;
		
		isstru=Coustemer_db_utill.add_Coustemer(first_name, last_name, conact, email);
		if(isstru == true) {
			 
			  
			  
			 
			 RequestDispatcher dis = request.getRequestDispatcher("home.jsp");
			 dis.forward(request, response);
			
		}
		else {
			RequestDispatcher dis1 = request.getRequestDispatcher("unsucsees.jsp");
			dis1.forward(request, response);
			
		}	
		
		
 	}

}
