package com.Coustemer;

public class coustemer {

	private	int coustomer_id;
	private String first_name;
	private String last_name;
	private String conact;
	private String email;
	
	
	public coustemer(int coustomer_id, String first_name, String last_name, String conact, String email) {
		 
		this.coustomer_id = coustomer_id;
		this.first_name = first_name;
		this.last_name = last_name;
		this.conact = conact;
		this.email = email;
	}


	
	public int getCoustomer_id() {
		return coustomer_id;
	}


	 


	public String getFirst_name() {
		return first_name;
	}


	 


	public String getLast_name() {
		return last_name;
	}


	 


	public String getConact() {
		return conact;
	}


	 


	public String getEmail() {
		return email;
	}


	 
	
	
	
	
	
}
