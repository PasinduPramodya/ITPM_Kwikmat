package com.Coustemer;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Stock.Stock_db_utill;

  @WebServlet("/Delete_Coustemer")
public class Delete_Coustemer extends HttpServlet {
	private static final long serialVersionUID = 1L;

  	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
  		
  		
  		
  		String ID=    request.getParameter("Cid");
		boolean  isTrue;
	  
		isTrue=Coustemer_db_utill.delete_Coustemer(ID);
			 
	
	 if(isTrue==true) {
	 
	 RequestDispatcher dis = request.getRequestDispatcher("home.jsp");
	 dis.forward(request, response);
	 }
	 
	 else {
		 
		 RequestDispatcher dis = request.getRequestDispatcher("#");
		 dis.forward(request, response);
		 
		 
	 }
  		
	}

}
