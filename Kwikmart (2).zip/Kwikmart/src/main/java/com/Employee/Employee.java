package com.Employee;

public class Employee {

	
	private int employee_ID;
	private String employee_name;
	private String contact_number;
	private String position;
	private String d_o_e;
	
	
	public Employee(int employee_ID, String employee_name, String contact_number, String position, String d_o_e) {
		 
		this.employee_ID = employee_ID;
		this.employee_name = employee_name;
		this.contact_number = contact_number;
		this.position = position;
		this.d_o_e = d_o_e;
	}


	public int getEmployee_ID() {
		return employee_ID;
	}

 

	public String getEmployee_name() {
		return employee_name;
	}


 

	public String getContact_number() {
		return contact_number;
	}


	 

	public String getPosition() {
		return position;
	}


 


	public String getD_o_e() {
		return d_o_e;
	}


 
	 
	
	
}
