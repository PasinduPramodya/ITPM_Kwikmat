package com.Employee;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.Stock.product;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class Employee_DB_Utill {

	

public static List<Employee>validate(String eid){
	
		
		ArrayList<Employee> emp = new ArrayList<>();
		
		String url="jdbc:mysql://localhost:3306/kwikmart";
    	String user="root";
    	String pass="Ashan123";														
																				
																				

		try {
																				
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="SELECT * FROM kwikmart.employee WHERE Employee_ID ='"+eid+"' ";
			
			ResultSet rs = stmt.executeQuery(sql);
			
			
			if (rs.next()){
			
			 
				
				
				int id=rs.getInt(1);
				String Name = rs.getString(2);
				String pNumber = rs.getString(3);
				String Position = rs.getString(4); 
				String doe= rs.getString(5);
				 
				 
			
				Employee p = new Employee(id,Name,pNumber,Position,doe);
				emp.add(p);
			}
			else {
				
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
		
		return emp;
		
	}
	
	
	
	
	

    public static boolean Add_employee(String name,String pnumber, String position, String doe ) {
		
    	boolean isSuccess = false;
    	
    	
    	String url="jdbc:mysql://localhost:3306/kwikmart";
    	String user="root";
    	String pass="Ashan123";
    	
    	
try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="INSERT INTO kwikmart.employee values(0,'"+name+"','"+pnumber+"','"+position+"','"+doe+"')";
			int rs = stmt.executeUpdate(sql);
			
			
			if (rs>0) {
				
			isSuccess= true;	
				
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
    	
    	
    	
    	
    	
    	return isSuccess;
    	
    }
    
    
    
    
    
    public static boolean Update_Employee(String id,String name,String conta, String posi, String doe ) {
   		
       	boolean isSuccess = false;
       	
       	
       	
       	String url="jdbc:mysql://localhost:3306/kwikmart";
       	String user="root";
       	String pass="Ashan123";
       	
       	
   try {
   			
   			Class.forName("com.mysql.jdbc.Driver");
   			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
   			Statement stmt = (Statement) con.createStatement();
   			String sql ="update kwikmart.employee set Employee_Name ='"+name+"' ,Contact_Number ='"+conta +"' ,Employee_Position ='"+posi +"' , Date_of_entry='"+doe+"'   where  Employee_ID ='"+id +"'  ";
   			int rs = stmt.executeUpdate(sql);
   			
   			 
   			
   			
   			
   			
   			
   			if (rs>0) {
   				
   			isSuccess= true;	
   				
   			}
   			else {
   				isSuccess = false;
   			}
   			
   		}
   		catch(Exception e) {
   			e.printStackTrace();
   		}
   		
       	
       	
       	
       	
       	
       	return isSuccess;
       	
       }
       
    


	public static boolean Delete_Employee(String ID) {
		
		int id = Integer.parseInt(ID);
		
		
     boolean isSuccess = false;
		
		

		
 	String url="jdbc:mysql://localhost:3306/kwikmart";
	String user="root";
	String pass="Ashan123";
		
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = (Connection) DriverManager.getConnection(url,user,pass);
			Statement stmt = (Statement) con.createStatement();
			String sql ="DELETE FROM kwikmart.employee where Employee_ID ='"+id +"' ";	
			int rs = stmt.executeUpdate(sql);
			
			if (rs>0) {
				        
			isSuccess= true;	
				
			}
			else {
				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
		
		
		
	}
	
    
    
	
	
}
