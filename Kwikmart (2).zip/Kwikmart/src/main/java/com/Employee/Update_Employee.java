package com.Employee;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 

   @WebServlet("/Update_Employee")
public class Update_Employee extends HttpServlet {
	private static final long serialVersionUID = 1L;

  	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

  	
  		String id = request.getParameter("eid");
  		String name = request.getParameter("name");
		String cont = request.getParameter("cnum");
		String  posi= request.getParameter("empos");
		String doe = request.getParameter("doe");
	 
		 
		
		boolean isstru;
		
		isstru= Employee_DB_Utill.Update_Employee(id, name, cont, posi, doe);
			
		if(isstru == true) {
 		 RequestDispatcher dis = request.getRequestDispatcher("home.jsp");
			 dis.forward(request, response);
			
		}
		else {
			RequestDispatcher dis1 = request.getRequestDispatcher("unsucsees.jsp");
			dis1.forward(request, response);
			
		}
		
  		
  		
  		
  		
  		
  		
  	}

}
