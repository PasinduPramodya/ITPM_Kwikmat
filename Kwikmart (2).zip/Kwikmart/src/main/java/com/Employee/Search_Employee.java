package com.Employee;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 
import com.Stock.product;

 
@WebServlet("/Search_Employee")
public class Search_Employee extends HttpServlet {
	private static final long serialVersionUID = 1L;

 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		 
		String empID = request.getParameter("EID");
	
		try {
		 List<Employee> Employee_Details =  Employee_DB_Utill.validate(empID);
		 request.setAttribute("Employee_Details",Employee_Details);
		}
		catch(Exception e) {
			  e.printStackTrace();
		  }
		
		 RequestDispatcher dis = request.getRequestDispatcher("Employee_account.jsp");
		 dis.forward(request, response);
		
		
		
	}

}
